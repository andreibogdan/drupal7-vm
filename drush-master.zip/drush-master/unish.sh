# Run Unish, the test suite for Drush.
cd tests && ../vendor/bin/phpunit $@
